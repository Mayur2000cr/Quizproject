package bean;

import java.sql.ResultSet;

public class Quiz {
	private ResultSet result;

	public ResultSet getResult() {
		return result;
	}

	public void setResult(ResultSet result) {
		this.result = result;
	}
}
