package bean;

public class makequizbean {
	
	private String subject;
	private int subid;
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
		System.out.println(this.subject);
	}
	public int getSubid() {
		return subid;
	}
	public void setSubid(int subid) {
		this.subid = subid;
	}
	
	
	
}
